const Sequelize = require('sequelize');
const sequelize = new Sequelize('test', 'root', 'admin', {
    host: "localhost",
    dialect: 'mysql'
});

sequelize.authenticate().then(function(){
    console.log("Conectado com sucesso! ")
}).catch(function(erro){
    console.log("Falha ao se conectar" + erro)
});

// Model Postagem
const Postagem = sequelize.define('postagem', {
    titulo: {
        type: Sequelize.STRING
    },
    conteudo: {
        type: Sequelize.TEXT
    }
});

// Usuarios
const Usuarios = sequelize.define('usuarios', {
    nome: {
        type: Sequelize.STRING
    },
    sobrenome: {
        type: Sequelize.STRING
    },
    idade: {
        type: Sequelize.INTEGER
    },
    email: {
        type: Sequelize.STRING
    },
});

Usuarios.create({
    nome: "Vitor",
    sobrenome: "Gabriel Gransotto",
    idade: 18,
    email: "Gransotto2002@hotmail.com"

});