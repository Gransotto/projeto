// requisição do express
const express = require("express");

//a constante app leva o pacote express nela
const app = express();

//a função "app".get cria uma nova rota na aplicação, fazendo com que seja possível a criação de ramificações de programas muito grandes
app.get("/", function(req, res){
    res.send("Seja bem vindo ao meu web")
});

app.get("/sobre", function(req, res){
    res.sendFile(__dirname + "/html/sobre.html")
});

//O res.sendFile é responsável por enviar um arquivo, diferentemente do "res.send()"
app.get("/blog", function(req, res){
    res.sendFile(__dirname + "/html/index.html")
});

app.get("/ola/:nome/:cargo/:idade", function(req, res){
    res.send("<h1>Olá "+req.params.nome+" Ficamos sabendo que voce e "+req.params.cargo+"</h1>")
});




// abertura do servidor com express , deve ficar no final da aplicação sempre
app.listen(8081, function(){
    console.log("Servidor rodando na 8081")
});
