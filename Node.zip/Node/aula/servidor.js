var http = require('http')

http.createServer(function(req, res){
    res.end("E ae meeen")
}).listen(8081);

console.log("Servidor esta rodando")