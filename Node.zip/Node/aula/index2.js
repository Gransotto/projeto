const express = require("express");
const app = express();
const handlebars = require("express-handlebars");
const Sequelize = require('sequelize');
const Bodyparser = require('body-parser');
const bodyParser = require("body-parser");

// Config
    // Template Engine
        app.engine("handlebars", handlebars({defaultLayout: 'main'}))
        app.set('view engine', 'handlebars')

    // BodyParser
        app.use(bodyParser.urlencoded({extended: false}));
        app.use(bodyParser.json());

    // Conexao banco de dados
    const sequelize = new Sequelize('test', 'root', 'admin', {
        host: "localhost",
        dialect: 'mysql'
    });

// Rotas
    app.get('/cad', function(req, res){
        res.render('formulario')
    });    

// Usamos o app.post quando queremos enviar dados
    app.post('/add', function(req, res){
        //req.body.(nome) carrega os dados enviados pelo post !
        res.send('Texto : ' + req.body.titulo+' Conteudo : '+ req.body.conteudo)
    });





app.listen(8081, function(){
    console.log("Servidor rodando na 8081")
});
